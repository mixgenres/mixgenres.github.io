import type { InstrumentDSPOverride } from '../physicalDspProfile';

/** Deep physical profile override for Slow string ensemble. Generated from this instrument's luthierPhysics, techniques, playingStyles and acoustic role; not a generic family alias. */
export const dspOverride: InstrumentDSPOverride = {
  "instrumentCharacter": {
    "energySource": "bow",
    "energyPath": "bow/string/bridge/body",
    "bodyArchitecture": "instrument-specific chamber",
    "primaryCollision": "stick-slip friction",
    "asymmetries": [],
    "couplingPaths": [],
    "techniqueBindings": [
      "arco",
      "detaché",
      "legato bow",
      "pizzicato"
    ]
  },
  "excitationDynamics": {
    "hardness": 0.36,
    "pressureSensitivity": 0.84,
    "nonlinearDrive": 0.105,
    "attackCollision": 0.54,
    "spectralSpread": 0.579,
    "directionalAsymmetry": 0.54
  },
  "coupledResonators": {
    "bodyModes": [
      {
        "ratio": 0.55,
        "q": 2.0,
        "gain": 0.145
      },
      {
        "ratio": 1.0,
        "q": 2.45,
        "gain": 0.112
      },
      {
        "ratio": 1.72,
        "q": 2.9,
        "gain": 0.102
      },
      {
        "ratio": 2.63,
        "q": 3.35,
        "gain": 0.096
      }
    ]
  },
  "mechanicalArtifacts": {
  "airHiss": 0,
  "keyThud": 0,
  "valveClick": 0,
  "fretBuzz": 0,
  "stringSqueak": 0.09,
  "pickZing": 0,
  "handContact": 0.06,
  "bodyKnock": 0.04,
  "rimImpact": 0,
  "bellowsNoise": 0,
  "damperNoise": 0.05,
  "palletClick": 0,
  "slideNoise": 0,
  "reedChatter": 0,
  "bellowsFold": 0,
  "bowRosin": 0.16,
  "hammerClick": 0,
  "pedalNoise": 0,
  "membraneFingerNoise": 0,
  "seedRattle": 0,
  "fippleNoise": 0,
  "muteContact": 0,
  "breathBurst": 0,
  "keyworkClick": 0
},
  "articulationPhysics": {
    "strikeZoneLocation": "fingerboard",
    "fleshVsNail": 0,
    "handDamping": 0,
    "attackToPitchCoupling": 0.396,
    "releaseCoupling": 0.43,
    "continuousSustain": true,
    "noteTransition": "legato"
  },
  "genreDialects": {
    "orchestral": {
      "excitationBias": 0,
      "brightness": 1.0,
      "damping": 0,
      "attack": 1.0,
      "articulation": [
        "arco",
        "detaché",
        "legato bow",
        "pizzicato"
      ]
    },
    "cinematic": {
      "excitationBias": 0,
      "brightness": 1.0,
      "damping": 0,
      "attack": 1.0,
      "articulation": [
        "arco",
        "detaché",
        "legato bow",
        "pizzicato"
      ]
    },
    "pop": {
      "excitationBias": 0,
      "brightness": 1.0,
      "damping": 0,
      "attack": 1.0,
      "articulation": [
        "arco",
        "detaché",
        "legato bow",
        "pizzicato"
      ]
    }
  },
  "physicalDetails": {
  "system": "instrument-specific",
  "construction": "declared acoustic/electronic construction",
  "exciter": "declared excitation",
  "asymmetries": [
    "performance-state dependence"
  ],
  "coupling": [
    "exciter-resonator",
    "body/air transfer"
  ],
  "artifactSources": [
    "contact noise"
  ],
  "detail": [
    "slow-strings requires instrument-specific calibration rather than generic family identity"
  ],
  "response": {
    "contactHardness": 0.542,
    "resonatorQ": 0.98,
    "nonlinearTransfer": 0.213,
    "inharmonicity": 0.071,
    "bodyCoupling": 0.98
  }
}
} as InstrumentDSPOverride;
