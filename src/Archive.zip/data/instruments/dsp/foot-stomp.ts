import type { InstrumentDSPOverride } from '../physicalDspProfile';

/** Deep physical profile override for Foot stomp. Generated from this instrument's luthierPhysics, techniques, playingStyles and acoustic role; not a generic family alias. */
export const dspOverride: InstrumentDSPOverride = {
  "instrumentCharacter": {
    "energySource": "impact",
    "energyPath": "body/air",
    "bodyArchitecture": "instrument-specific chamber",
    "primaryCollision": "wood/flesh collision",
    "asymmetries": [],
    "couplingPaths": [],
    "techniqueBindings": [
      "heavy heel slam",
      "ball-of-foot tap",
      "stage floor resonant thump",
      "clogging heel-toe syncopation"
    ]
  },
  "excitationDynamics": {
    "hardness": 0.6,
    "pressureSensitivity": 0.46,
    "nonlinearDrive": 0.148,
    "attackCollision": 0.8,
    "spectralSpread": 0.704,
    "directionalAsymmetry": 0.12
  },
  "coupledResonators": {
    "bodyModes": [
      {
        "ratio": 0.58,
        "q": 2.0,
        "gain": 0.176
      },
      {
        "ratio": 1.0,
        "q": 2.45,
        "gain": 0.128
      },
      {
        "ratio": 1.73,
        "q": 2.9,
        "gain": 0.112
      },
      {
        "ratio": 2.91,
        "q": 3.35,
        "gain": 0.104
      }
    ]
  },
  "mechanicalArtifacts": {
  "airHiss": 0,
  "keyThud": 0,
  "valveClick": 0,
  "fretBuzz": 0,
  "stringSqueak": 0,
  "pickZing": 0,
  "handContact": 0.12,
  "bodyKnock": 0.08,
  "rimImpact": 0,
  "bellowsNoise": 0,
  "damperNoise": 0,
  "palletClick": 0,
  "slideNoise": 0,
  "reedChatter": 0,
  "bellowsFold": 0,
  "bowRosin": 0,
  "hammerClick": 0,
  "pedalNoise": 0,
  "membraneFingerNoise": 0.16,
  "seedRattle": 0,
  "fippleNoise": 0,
  "muteContact": 0,
  "breathBurst": 0,
  "keyworkClick": 0
},
  "articulationPhysics": {
    "strikeZoneLocation": "mixed",
    "fleshVsNail": 0.18,
    "handDamping": 0,
    "attackToPitchCoupling": 0.228,
    "releaseCoupling": 0.18,
    "continuousSustain": false,
    "noteTransition": "retrigger"
  },
  "genreDialects": {
    "folk": {
      "excitationBias": 0,
      "brightness": 1.0,
      "damping": 0,
      "attack": 1.0,
      "articulation": [
        "heavy heel slam",
        "ball-of-foot tap",
        "stage floor resonant thump",
        "clogging heel-toe syncopation"
      ]
    },
    "blues": {
      "excitationBias": 0,
      "brightness": 1.0,
      "damping": 0,
      "attack": 1.0,
      "articulation": [
        "heavy heel slam",
        "ball-of-foot tap",
        "stage floor resonant thump",
        "clogging heel-toe syncopation"
      ]
    },
    "celtic": {
      "excitationBias": 0,
      "brightness": 1.0,
      "damping": 0,
      "attack": 1.0,
      "articulation": [
        "heavy heel slam",
        "ball-of-foot tap",
        "stage floor resonant thump",
        "clogging heel-toe syncopation"
      ]
    },
    "flamenco": {
      "excitationBias": 0,
      "brightness": 1.0,
      "damping": 0,
      "attack": 1.0,
      "articulation": [
        "heavy heel slam",
        "ball-of-foot tap",
        "stage floor resonant thump",
        "clogging heel-toe syncopation"
      ]
    },
    "bluegrass": {
      "excitationBias": 0,
      "brightness": 1.0,
      "damping": 0,
      "attack": 1.0,
      "articulation": [
        "heavy heel slam",
        "ball-of-foot tap",
        "stage floor resonant thump",
        "clogging heel-toe syncopation"
      ]
    }
  },
  "physicalDetails": {
  "system": "contact-noise-idiophone",
  "construction": "instrument-specific rigid/skin contact structure",
  "exciter": "friction/impact/hand/stick",
  "asymmetries": [
    "stroke direction",
    "contact location",
    "fill material or plate geometry"
  ],
  "coupling": [
    "exciter-material",
    "body resonance",
    "secondary particles where applicable"
  ],
  "artifactSources": [
    "contact noise",
    "body knock",
    "secondary rattles"
  ],
  "detail": [
    "timbral identity comes from contact geometry",
    "noise density follows stroke speed",
    "secondary resonances are short and material-dependent"
  ],
  "response": {
    "contactHardness": 0.622,
    "resonatorQ": 0.98,
    "nonlinearTransfer": 0.158,
    "inharmonicity": 0.087,
    "bodyCoupling": 0.98
  }
}
} as InstrumentDSPOverride;
