import { INSTRUMENTS_BY_ID } from '../../data/instruments';
import WebRenderer from '@elemaudio/web-renderer';
import { el } from '@elemaudio/core';
import type { LuthierPhysicalParameters } from './LuthierAPI';
import type { MasterChain } from './mixer';
import { createMasterChain, getRoleGainLinear } from './mixer';
import { CulturalAcousticEvent } from '../theory/CulturalAcousticEvent';
import {
  defaultTrackParams,
  modelForInstrument,
  makeupGainFor,
  renderTrack,
  renderMaster,
  midiToFreq,
  type TrackParams,
  type VoiceState,
} from '../elementary/elementaryEngine';

import { resolveDialect, performanceModeForContext } from '../theory/dialects';
import { resolveRenderGesture } from './renderGesture';
import { contractForGenre } from '../../data/styles/contracts';
import type { AudioSignal } from '../instruments/types';

interface RendererNodeEntry {
  props: Record<string, unknown>;
}

interface RendererDelegate {
  clear(): void;
  nodeMap: Map<number, RendererNodeEntry>;
  setProperty(hash: number, property: string, value: number): void;
  commitUpdates(): void;
  getPackedInstructions(): { length: number };
}

interface RendererInternals {
  _delegate?: RendererDelegate;
  _sendMessage(instructions: unknown): void;
}

export function getPolyphonyForTrack(instrumentId: string, role?: string): number {
  const idLower = (instrumentId || '').toLowerCase();
  const def = INSTRUMENTS_BY_ID[instrumentId] || INSTRUMENTS_BY_ID[idLower];
  if (typeof def?.polyphony === 'number') return def.polyphony;
  const r = (role || '').toLowerCase();
  const inst = idLower;
  if (r === 'bass' || /bass|tuba|sousaphone/i.test(inst)) return 4;
  if (r === 'lead' || r === 'voice' || r === 'melody' || /sax|flute|trumpet|violin|whistle|oboe|clarinet/i.test(inst)) return 4;
  if (r === 'drums' || /drums|kick|snare|hats|cajon|timbales|conga|bongo/i.test(inst)) return 12;
  if (r === 'comp' || r === 'pad' || /piano|rhodes|clav|guitar|harp|strings|organ|synth/i.test(inst)) return 8;
  return 8;
}

/**
 * Elementary Audio live engine.
 * Natural acoustic/electronic physical model summation with conservative mastering.
 */
export class BandWorkletNode {
  /**
   * @static
   */
  public static readonly MAX_POLYPHONY = 32;

  private ctx!: AudioContext;
  private core!: InstanceType<typeof WebRenderer>;
  private audioNode!: AudioNode;
  private voiceSeq = 0;
  private masterChain?: MasterChain;

  private timerIds = new Set<number>();

  public activeWorldId = 'flamenco';
  public activeStyleId = '';

  private masterVolume = 1.0;
  private trackParamsMap = new Map<string, TrackParams>();
  private trackVoicesMap = new Map<string, VoiceState[]>();

  // Tier 4: Live mix state and per-track signal caching
  private trackMutedMap = new Map<string, boolean>();
  private trackSoloMap = new Map<string, boolean>();
  private trackVolumes = new Map<string, number>();
  private trackPans = new Map<string, number>();
  private trackSignalsCache = new Map<string, { fingerprint: string; signal: { left: AudioSignal; right: AudioSignal } }>();
  private dirtyTracks = new Set<string>();

  // Real-time parameter updates without dynamic graph reconstruction
  private paramHashes = new Map<string, number>();
  private pendingParamUpdates: Record<string, number> = {};
  private paramFlushScheduled = false;

  private getHashForKey(key: string): number {
    const existing = this.paramHashes.get(key);
    if (existing !== undefined) return existing;
    const hash = el.const({ key, value: 0 }).hash;
    if (hash === undefined) throw new Error(`Unable to allocate parameter hash for ${key}`);
    this.paramHashes.set(key, hash);
    return hash;
  }

  public updateMap(updates: Record<string, number>) {
    this.applyParamUpdates(updates);
  }

  private queueParamUpdate(key: string, value: number) {
    this.pendingParamUpdates[key] = value;
    if (!this.paramFlushScheduled) {
      this.paramFlushScheduled = true;
      if (typeof queueMicrotask !== 'undefined') {
        queueMicrotask(() => {
          this.paramFlushScheduled = false;
          this.flushParamUpdates();
        });
      } else {
        setTimeout(() => {
          this.paramFlushScheduled = false;
          this.flushParamUpdates();
        }, 0);
      }
    }
  }

  public flushParamUpdates() {
    const keys = Object.keys(this.pendingParamUpdates);
    if (keys.length === 0) return;
    const updates = this.pendingParamUpdates;
    this.pendingParamUpdates = {};
    this.applyParamUpdates(updates);
  }

  private applyParamUpdates(updates: Record<string, number>) {
    const renderer = (this.core as unknown as { _renderer?: RendererInternals })._renderer;
    if (!renderer || !renderer._delegate) return;
    const delegate = renderer._delegate;

    delegate.clear();
    let hasUpdates = false;

    for (const [key, value] of Object.entries(updates)) {
      const hash = this.getHashForKey(key);
      if (delegate.nodeMap.has(hash)) {
        const entry = delegate.nodeMap.get(hash);
        if (!entry) continue;
        delegate.setProperty(hash, 'value', value);
        entry.props['value'] = value;
        hasUpdates = true;
      }
    }

    if (hasUpdates) {
      delegate.commitUpdates();
      const instructions = delegate.getPackedInstructions();
      if (instructions && instructions.length > 0) {
        renderer._sendMessage(instructions);
      }
    }
  }

  setWorldAndStyle(worldId: string, styleId?: string) {
    this.activeWorldId = worldId;
    this.activeStyleId = styleId || '';
    if (worldId && this.masterChain) {
      try {
        const contract = contractForGenre(worldId);
        if (contract?.timbreSpace?.mixCharacter) {
          this.masterChain.setMixCharacter(contract.timbreSpace.mixCharacter, worldId);
        }
      } catch {
        // world not yet defined or invalid id
      }
    }
  }

  async initialize(context: AudioContext, volume = 1): Promise<AudioNode> {
    this.ctx = context;
    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => { });
    }

    this.core = new WebRenderer();

    this.audioNode = await this.core.initialize(context, {
      numberOfInputs: 0,
      numberOfOutputs: 1,
      outputChannelCount: [2],
    });

    if (this.masterChain) {
      this.masterChain.dispose();
    }
    let initialMixChar: import('../../data/styles/contracts').MixCharacter | undefined;
    if (this.activeWorldId) {
      try {
        initialMixChar = contractForGenre(this.activeWorldId)?.timbreSpace?.mixCharacter;
      } catch {}
    }
    this.masterChain = createMasterChain(context, initialMixChar, this.activeWorldId);
    this.masterChain.setVolume(volume);
    this.audioNode.connect(this.masterChain.input);

    this.masterVolume = volume;
    this.syncGraph();
    return this.masterChain.output;
  }

  async setVolume(value: number) {
    this.masterVolume = Math.max(0, Math.min(2, value));
    this.masterChain?.setVolume(value);
    this.syncGraph();
  }

  // Live mix methods (Tier 3 -> Tier 4 live parameter update, no graph reconstruction)
  setTrackVolume(trackId: string, volume: number, atTime?: number) {
    this.schedule(() => {
      this.trackVolumes.set(trackId, volume);
      const params = this.trackParamsMap.get(trackId);
      if (params) {
        params.volume = volume;
      }
      const isMuted = !!this.trackMutedMap.get(trackId);
      const hasAnySolo = Array.from(this.trackSoloMap.values()).some(Boolean);
      const isSoloed = !!this.trackSoloMap.get(trackId);
      const effectiveVol = (isMuted || (hasAnySolo && !isSoloed)) ? 0 : volume;
      this.queueParamUpdate(`track_${trackId}_vol`, effectiveVol);
      this.flushParamUpdates();
    }, atTime);
  }

  setTrackMute(trackId: string, muted: boolean, atTime?: number) {
    this.schedule(() => {
      this.trackMutedMap.set(trackId, muted);
      this.updateTrackMuteSoloLevels();
    }, atTime);
  }

  setTrackSolo(trackId: string, solo: boolean, atTime?: number) {
    this.schedule(() => {
      this.trackSoloMap.set(trackId, solo);
      this.updateTrackMuteSoloLevels();
    }, atTime);
  }

  private updateTrackMuteSoloLevels() {
    const hasAnySolo = Array.from(this.trackSoloMap.values()).some(Boolean);
    for (const [trackId, params] of this.trackParamsMap.entries()) {
      const isMuted = !!this.trackMutedMap.get(trackId);
      const isSoloed = !!this.trackSoloMap.get(trackId);
      const isSilenced = isMuted || (hasAnySolo && !isSoloed);
      const effectiveVol = isSilenced ? 0 : (params.volume ?? 1);
      this.queueParamUpdate(`track_${trackId}_vol`, effectiveVol);
    }
    this.flushParamUpdates();
  }

  setTrackPan(trackId: string, pan: number, atTime?: number) {
    this.schedule(() => {
      this.trackPans.set(trackId, pan);
      const params = this.trackParamsMap.get(trackId);
      if (params) params.pan = pan;
      const clampedPan = Math.max(0, Math.min(1, pan));
      const leftGain = Math.cos(clampedPan * Math.PI * 0.5);
      const rightGain = Math.sin(clampedPan * Math.PI * 0.5);
      this.queueParamUpdate(`track_${trackId}_panL`, leftGain);
      this.queueParamUpdate(`track_${trackId}_panR`, rightGain);
      this.flushParamUpdates();
    }, atTime);
  }

  setTrackSpotlight(_trackId: string, _mode: string, atTime?: number) {
    this.schedule(() => {
      this.updateTrackMuteSoloLevels();
    }, atTime);
  }

  private markDirty(trackId: string) {
    this.dirtyTracks.add(trackId);
  }

  /**
   * Pre-allocates all tracks in the track params and voices maps with right-sized polyphony.
   * Calls syncGraph ONLY if an instrument was added, removed, or changed.
   */
  async prepareTracks(instrumentsMap: Map<string, string>) {
    let graphDirty = false;

    // Clean up tracks that were removed from the song
    for (const trackId of Array.from(this.trackParamsMap.keys())) {
      if (!instrumentsMap.has(trackId)) {
        this.trackParamsMap.delete(trackId);
        this.trackVoicesMap.delete(trackId);
        this.trackSignalsCache.delete(trackId);
        this.dirtyTracks.delete(trackId);
        graphDirty = true;
      }
    }

    for (const [trackId, instrumentId] of instrumentsMap.entries()) {
      const existing = this.trackParamsMap.get(trackId);
      if (!existing || existing.instrumentId !== instrumentId) {
        const instDef = INSTRUMENTS_BY_ID[instrumentId];
        const instLuthier: LuthierPhysicalParameters = instDef?.luthierPhysics ?? {
          category: 'electro_acoustic_algorithmic',
          materialDensity: 0.5,
          tension: 0.5,
          bodyResonanceVolume: 10,
          decayTimeFactor: 2,
          harmonicRichness: 0.7,
        };
        const model = instDef?.elementaryModel ?? modelForInstrument(instrumentId);
        const params = defaultTrackParams(instrumentId, instLuthier, model);
        params.performanceMode = performanceModeForContext(this.activeWorldId, this.activeStyleId);
        if (this.activeWorldId) {
          params.genreId = this.activeWorldId;
        }
        const dialect = resolveDialect(instrumentId, this.activeWorldId, this.activeStyleId);
        if (dialect) {
          params.dialect = dialect.id;
          params.performanceMode = dialect.performanceMode;
          if (dialect.pluckPositionOverride !== undefined) params.pluckPosition = dialect.pluckPositionOverride;
          if (dialect.bowPressureOverride !== undefined) params.bowPressure = dialect.bowPressureOverride;
          if (dialect.contactPointOverride !== undefined) params.contact = dialect.contactPointOverride;
          if (dialect.brightnessMultiplier !== undefined) params.brightness *= dialect.brightnessMultiplier;
          if (dialect.decayMultiplier !== undefined) params.decay *= dialect.decayMultiplier;
          if (dialect.bodyMultiplier !== undefined) params.body *= dialect.bodyMultiplier;
          if (dialect.bendGlideMs !== undefined) params.bendGlideMs = dialect.bendGlideMs;
        }
        const role = instDef?.acousticProfile?.role || 'comp';
        params.roleGain = getRoleGainLinear(role, this.activeWorldId || 'default', instrumentId);
        this.trackParamsMap.set(trackId, params);

        const voiceCount = getPolyphonyForTrack(instrumentId);
        const preallocatedVoices: VoiceState[] = [];
        for (let vIdx = 0; vIdx < voiceCount; vIdx++) {
          preallocatedVoices.push({
            id: `live-${trackId}-v${vIdx}`,
            gate: 0,
            frequencyHz: 440,
            note: 60,
            velocity: 0,
          });
        }
        this.trackVoicesMap.set(trackId, preallocatedVoices);
        this.markDirty(trackId);
        graphDirty = true;
      }
    }
    if (graphDirty) {
      this.syncGraph();
    }
  }

  /**
   * Only hashes the track's instrument assignment and static macro parameters.
   * Completely ignores voice states (gate, note, velocity, frequency).
   */
  private computeTrackFingerprint(trackId: string, params: TrackParams): string {
    return `${trackId}:${params.instrumentId}:${params.model}:${params.dialect || ''}:${params.performanceMode || ''}:${(params.brightness * 100).toFixed(0)}:${(params.decay * 10).toFixed(0)}:${(params.drive * 100).toFixed(0)}:${(params.body * 100).toFixed(0)}:${(params.tension * 100).toFixed(0)}`;
  }

  private syncGraph() {
    if (!this.core) return;

    let anyDirty = false;
    for (const [trackId, params] of this.trackParamsMap.entries()) {
      const fp = this.computeTrackFingerprint(trackId, params);
      const cached = this.trackSignalsCache.get(trackId);

      if (!cached || cached.fingerprint !== fp) {
        anyDirty = true;
        const voices = this.trackVoicesMap.get(trackId) ?? [];
        const sig = renderTrack(trackId, voices, params);
        this.trackSignalsCache.set(trackId, { fingerprint: fp, signal: sig });
      }
    }

    if (!anyDirty && this.trackSignalsCache.size > 0) {
      this.dirtyTracks.clear();
      return;
    }

    const trackSignals: {
      left: AudioSignal;
      right: AudioSignal;
      trackId?: string;
      instrumentId?: string;
      role?: string;
    }[] = [];

    for (const [trackId, params] of this.trackParamsMap.entries()) {
      const cached = this.trackSignalsCache.get(trackId);
      if (cached) {
        trackSignals.push({
          left: cached.signal.left,
          right: cached.signal.right,
          trackId,
          instrumentId: params.instrumentId,
          role: INSTRUMENTS_BY_ID[params.instrumentId ?? '']?.acousticProfile?.role,
        });
      }
    }

    let mixCharacter: import('../../data/styles/contracts').MixCharacter | undefined;
    if (this.activeWorldId) {
      try {
        mixCharacter = contractForGenre(this.activeWorldId)?.timbreSpace?.mixCharacter;
      } catch {
        /* ignore missing contract */
      }
    }

    const masterSig = renderMaster(trackSignals, {
      highPass: 20,
      volume: this.masterVolume,
      mixCharacter,
      genreId: this.activeWorldId,
      bpm: 120,
    });
    this.core.render(masterSig.left, masterSig.right).catch((err: unknown) => {
      console.warn('[Elementary] Render error:', err);
    });

    this.dirtyTracks.clear();
  }

  private schedule(fn: () => void, atTime?: number) {
    const now = this.ctx?.currentTime ?? 0;
    const delay = Math.max(0, (atTime ?? now) - now);
    if (delay <= 0.005) {
      fn();
    } else {
      const id = window.setTimeout(() => {
        this.timerIds.delete(id);
        fn();
      }, delay * 1000);
      this.timerIds.add(id);
    }
  }

  processPendingEvents() {
    this.flushParamUpdates();
  }

  postEvent(event: CulturalAcousticEvent, atTime?: number) {
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => { });
    }
    this.schedule(() => {
      this.executeNoteOn(event);
    }, atTime);
  }

  private executeNoteOn(event: CulturalAcousticEvent) {
    const trackId = event.trackId;
    const instrumentId = event.luthierObjectId || trackId;
    const instDef = INSTRUMENTS_BY_ID[instrumentId];
    const luthier = (event.luthier ?? instDef?.luthierPhysics ?? {
      category: 'electro_acoustic_algorithmic',
      materialDensity: 0.5,
      tension: 0.5,
      bodyResonanceVolume: 10,
      decayTimeFactor: 2,
      harmonicRichness: 0.7,
    }) as LuthierPhysicalParameters;
    const model = modelForInstrument(instrumentId);

    if (!this.trackParamsMap.has(trackId)) {
      const p = defaultTrackParams(instrumentId, luthier, model);
      p.performanceMode = performanceModeForContext(this.activeWorldId, this.activeStyleId);
      const dialect = resolveDialect(instrumentId, this.activeWorldId, this.activeStyleId);
      if (dialect) {
        p.dialect = dialect.id;
        p.performanceMode = dialect.performanceMode;
        if (dialect.pluckPositionOverride !== undefined) p.pluckPosition = dialect.pluckPositionOverride;
        if (dialect.bowPressureOverride !== undefined) p.bowPressure = dialect.bowPressureOverride;
        if (dialect.contactPointOverride !== undefined) p.contact = dialect.contactPointOverride;
        if (dialect.brightnessMultiplier !== undefined) p.brightness *= dialect.brightnessMultiplier;
        if (dialect.decayMultiplier !== undefined) p.decay *= dialect.decayMultiplier;
        if (dialect.bodyMultiplier !== undefined) p.body *= dialect.bodyMultiplier;
        if (dialect.bendGlideMs !== undefined) p.bendGlideMs = dialect.bendGlideMs;
      }
      this.trackParamsMap.set(trackId, p);
    }

    const params = this.trackParamsMap.get(trackId)!;
    const noteMidi = event.midi ?? 60;
    const isElectronic = /synth|808|909|acid|sub-bass|kizomba|tarraxo|trap|house/.test((params.instrumentId || '').toLowerCase());
    const effectiveModelForGain = isElectronic ? 9 : params.model;
    const baseGain = makeupGainFor(effectiveModelForGain, params.instrumentId);

    const rendered = resolveRenderGesture(instrumentId, event.gestureCode ?? 0);
    const hitGainMultiplier = rendered.gainMultiplier;

    // Normalize event performance controls once per note. Keep velocity in the
    // renderer's canonical 0..1 range and fold gesture gain into the note-local
    // excitation rather than changing the track's static volume.
    const velRaw = Number.isFinite(event.velocity) ? event.velocity! : 102;
    const velScaled = Math.max(0, Math.min(1, (velRaw / 127) * hitGainMultiplier));
    const articulationNorm = Math.max(0, Math.min(1, rendered.articulationNorm));

    const roleGain = event.roleGain ?? params.roleGain ?? getRoleGainLinear(instDef?.acousticProfile?.role || 'comp', this.activeWorldId || 'default', instrumentId);
    // Keep track gain stable; note velocity/articulation are voice-local.
    params.volume = Math.max(0.01, Math.min(35, baseGain * roleGain));

    let voices = this.trackVoicesMap.get(trackId);
    if (!voices) {
      voices = [];
      const voiceCount = getPolyphonyForTrack(instrumentId);
      for (let vIdx = 0; vIdx < voiceCount; vIdx++) {
        voices.push({
          id: `live-${trackId}-v${vIdx}`,
          gate: 0,
          frequencyHz: 440,
          note: 60,
          velocity: 0,
        });
      }
      this.trackVoicesMap.set(trackId, voices);
    }

    // Round-robin voice allocation: prefer idle voice, then oldest triggered voice
    let bestVIdx = 0;
    let oldestSeq = Infinity;
    for (let i = 0; i < voices.length; i++) {
      const v = voices[i];
      if (v.gate === 0) {
        bestVIdx = i;
        break;
      }
      const seq = v.triggerSeq ?? 0;
      if (seq < oldestSeq) {
        oldestSeq = seq;
        bestVIdx = i;
      }
    }

    const voice = voices[bestVIdx];
    voice.note = noteMidi;
    voice.noteInstanceId = event.noteInstanceId;
    const targetFreq = Math.max(20, event.frequencyHz ?? midiToFreq(noteMidi));
    voice.frequencyHz = targetFreq;
    voice.baseFrequencyHz = targetFreq;
    voice.triggerSeq = ++this.voiceSeq;
    voice.velocity = velScaled;
    voice.gate = 1;

    voice.action = rendered.action;
    voice.articulation = rendered.articulationNorm;
    voice.bellowsDirectionCode = event.bellowsDirectionCode;
    voice.bandoneonButtonId = event.bandoneonButtonId;
    voice.bandoneonButtonIndex = event.bandoneonButtonIndex;
    voice.bandoneonSideCode = event.bandoneonSideCode;
    voice.action = rendered.action;
    voice.excitationType = rendered.excitationType || params.excitationType;

    voice.attack = event.attack;
    voice.decay = event.decay;
    voice.sustain = event.sustain;
    voice.release = event.release;

    // Apply parameter updates to static DSP nodes directly without core.render()
    const pk = `track_${trackId}_voice_${bestVIdx}`;
    this.queueParamUpdate(`${pk}_freq`, targetFreq);
    this.queueParamUpdate(`${pk}_vel`, velScaled * (1 - 0.58 * params.mute));
    this.queueParamUpdate(`${pk}_gate`, 1);
    this.queueParamUpdate(`${pk}_art`, articulationNorm);

    const velBoost = 0.55 + 0.6 * Math.max(0, Math.min(1, velScaled));
    const b = Math.max(0, Math.min(1, params.brightness * velBoost));
    const decayTime = Math.max(0.05, params.decay);
    const isMuted = params.mute > 0.4;
    const attack = event.attack !== undefined ? event.attack : (0.0008 + (1 - b) * 0.01);
    const release = event.release !== undefined ? event.release : (isMuted ? 0.012 : 0.03 + decayTime * 0.25);
    const sustain = event.sustain !== undefined ? event.sustain : (isMuted ? 0.05 : 0.35 + 0.3 * params.body);
    const envDecay = event.decay !== undefined ? event.decay : (decayTime * (isMuted ? 0.1 : 0.3));

    this.queueParamUpdate(`${pk}_attack`, attack);
    this.queueParamUpdate(`${pk}_decay`, envDecay);
    this.queueParamUpdate(`${pk}_sustain`, sustain);
    this.queueParamUpdate(`${pk}_release`, release);
    this.queueParamUpdate(`track_${trackId}_vol`, params.volume);
  }

  postRelease(trackId: string, midi: number, atTime?: number, noteInstanceId?: string) {
    this.schedule(() => {
      this.executeNoteOff(trackId, midi, noteInstanceId);
    }, atTime);
  }

  private executeNoteOff(trackId: string, midi: number, noteInstanceId?: string) {
    const voices = this.trackVoicesMap.get(trackId);
    if (!voices) return;

    const roundedMidi = Math.round(midi);
    for (let vIdx = 0; vIdx < voices.length; vIdx++) {
      const v = voices[vIdx];
      const idMatches = noteInstanceId ? String(v.noteInstanceId ?? '') === noteInstanceId : true;
      if (idMatches && (v.note === midi || Math.round(v.note) === roundedMidi) && v.gate === 1) {
        v.gate = 0;
        if (v.baseFrequencyHz) {
          v.frequencyHz = v.baseFrequencyHz;
        }
        const pk = `track_${trackId}_voice_${vIdx}`;
        this.queueParamUpdate(`${pk}_gate`, 0);
      }
    }
  }

  postCC(trackId: string, cc: number, value: number, atTime?: number) {
    this.schedule(() => {
      this.executeCC(trackId, cc, value);
    }, atTime);
  }

  private executeCC(trackId: string, cc: number, value: number) {
    const params = this.trackParamsMap.get(trackId);
    if (!params) return;

    const norm = value / 127;
    if (cc === 7 || cc === 11) {
      const isElectronic = /synth|808|909|acid|sub-bass|kizomba|tarraxo|trap|house/.test((params.instrumentId || '').toLowerCase());
      const effectiveModelForGain = isElectronic ? 9 : params.model;
      const baseGain = makeupGainFor(effectiveModelForGain, params.instrumentId);
      params.volume = Math.max(0.01, Math.min(35, norm * baseGain));
      this.queueParamUpdate(`track_${trackId}_vol`, params.volume);
    } else if (cc === 10) {
      params.pan = norm;
      const clampedPan = Math.max(0, Math.min(1, params.pan));
      const leftGain = Math.cos(clampedPan * Math.PI * 0.5);
      const rightGain = Math.sin(clampedPan * Math.PI * 0.5);
      this.queueParamUpdate(`track_${trackId}_panL`, leftGain);
      this.queueParamUpdate(`track_${trackId}_panR`, rightGain);
    } else if (cc === 16) {
      params.articulation = norm;
      const voices = this.trackVoicesMap.get(trackId) ?? [];
      for (let vIdx = 0; vIdx < voices.length; vIdx++) {
        this.queueParamUpdate(`track_${trackId}_voice_${vIdx}_art`, norm);
      }
    } else if (cc === 74) params.brightness = norm;
    else if (cc === 17) params.contact = norm;
    else if (cc === 18) params.mute = norm;
    else if (cc === 19) params.bowPressure = norm;
    else if (cc === 20) params.bowVelocity = norm;
    else if (cc === 21) params.bodyTap = norm;
    else if (cc === 22) params.pluckPosition = norm;
    else if (cc === 24) params.pressure = norm;
    else if (cc === 25) params.resonance = norm;
  }

  postBend(trackId: string, value: number, targetMidi?: number, atTime?: number) {
    this.schedule(() => {
      this.executeBend(trackId, value, targetMidi);
    }, atTime);
  }

  private executeBend(trackId: string, value: number, targetMidi?: number) {
    const voices = this.trackVoicesMap.get(trackId);
    if (!voices || voices.length === 0) return;

    const activeVoices: { voice: VoiceState; index: number }[] = [];
    for (let i = 0; i < voices.length; i++) {
      if (voices[i].gate === 1) activeVoices.push({ voice: voices[i], index: i });
    }
    if (activeVoices.length === 0) return;

    let target = activeVoices[0];
    if (targetMidi !== undefined) {
      const rounded = Math.round(targetMidi);
      const found = activeVoices.find(item => item.voice.note === targetMidi || Math.round(item.voice.note) === rounded);
      if (found) target = found;
    }

    const semitones = ((value - 8192) / 8192) * 2;
    const bendRatio = Math.pow(2, semitones / 12);
    const base = target.voice.baseFrequencyHz ?? target.voice.frequencyHz ?? midiToFreq(target.voice.note);
    target.voice.baseFrequencyHz = base;
    const targetFreq = base * bendRatio;
    target.voice.frequencyHz = targetFreq;

    this.queueParamUpdate(`track_${trackId}_voice_${target.index}_freq`, targetFreq);
  }

  softNotesOff() {
    for (const id of this.timerIds) window.clearTimeout(id);
    this.timerIds.clear();

    for (const [trackId, voices] of this.trackVoicesMap.entries()) {
      for (let vIdx = 0; vIdx < voices.length; vIdx++) {
        if (voices[vIdx].gate === 1) {
          voices[vIdx].gate = 0;
          this.queueParamUpdate(`track_${trackId}_voice_${vIdx}_gate`, 0);
        }
      }
    }
    this.flushParamUpdates();
  }

  clear() {
    for (const id of this.timerIds) window.clearTimeout(id);
    this.timerIds.clear();

    for (const [trackId, voices] of this.trackVoicesMap.entries()) {
      for (let vIdx = 0; vIdx < voices.length; vIdx++) {
        voices[vIdx].gate = 0;
        this.queueParamUpdate(`track_${trackId}_voice_${vIdx}_gate`, 0);
      }
    }
    this.flushParamUpdates();
  }

  dispose() {
    this.clear();
    this.trackVoicesMap.clear();
    this.trackParamsMap.clear();
    this.trackSignalsCache.clear();
    this.dirtyTracks.clear();
    try { this.audioNode?.disconnect(); } catch { }
    this.masterChain?.dispose();
    this.masterChain = undefined;
  }
}
